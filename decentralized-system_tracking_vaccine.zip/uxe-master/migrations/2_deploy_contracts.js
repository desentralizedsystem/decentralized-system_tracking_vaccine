const Tracking = artifacts.require("Tracking");

module.exports = function(deployer) {
  deployer.deploy(Tracking);
};
